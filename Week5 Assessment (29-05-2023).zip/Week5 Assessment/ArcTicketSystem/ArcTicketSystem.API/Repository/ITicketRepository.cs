﻿using ArcTicketSystem.API.Model;

namespace ArcTicketSystem.API.Repository
{
        public interface ITicketRepository
        {
            Task<IEnumerable<Ticket>> Get();
            Task<Ticket> Get(decimal Ticketid);
            Task<Ticket> Post(Ticket ticket);
            Task Update(Ticket ticket);
            Task Delete(decimal Ticketid);
        }
    
}
