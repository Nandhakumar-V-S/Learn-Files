﻿using ArcTicketSystem.API.DBContext;
using ArcTicketSystem.API.Model;
using Microsoft.EntityFrameworkCore;

namespace ArcTicketSystem.API.Repository
{
    public class TicketRepository : ITicketRepository
    {
        private readonly TicketContext _context;

        public TicketRepository(TicketContext context)

        {

            _context = context;

        }

        //public async Task<Ticket> Create(Ticket ticket)

        //{


        //    _context.Ticket.Add(ticket);

        //    await _context.SaveChangesAsync();

        //    return ticket;

        //}

        public async Task Delete(decimal Ticketid)

        {

            var ticketsDelete = await _context.Ticket.FindAsync(Ticketid);

            _context.Ticket.Remove(ticketsDelete);

            await _context.SaveChangesAsync();

        }

        public async Task<IEnumerable<Ticket>> Get()

        {
            return await _context.Ticket.ToListAsync();

        }

        public async Task<Ticket> Get(decimal Ticketid)

        {

            return await _context.Ticket.FindAsync(Ticketid);

        }

        public async Task<Ticket> Post(Ticket ticket)
        {
            ticket.Createdon = DateTime.UtcNow;
            ticket.Modifiedon = DateTime.UtcNow;

            _context.Ticket.Add(ticket);

            await _context.SaveChangesAsync();

            return ticket;
        }

        public async Task Update(Ticket ticket)

        {
            var extkt = _context.Ticket.FirstOrDefault(t => t.Ticketid == ticket.Ticketid);
            if (extkt != null)
            {
                ticket.Createdon = extkt.Createdon;

                extkt.Ticketname = ticket.Ticketname;
                extkt.Ticketcategory = ticket.Ticketcategory;
                extkt.Ticketdescription = ticket.Ticketdescription;
                extkt.Ticketstatus = ticket.Ticketstatus;
                extkt.Createdby = ticket.Createdby;
                extkt.Modifiedon = DateTime.Now;

                await _context.SaveChangesAsync();

            }

            //public async Task Update(Ticket ticket)

            //{

            //    _context.Entry(ticket).State = EntityState.Modified;

            //    await _context.SaveChangesAsync();

            //}

        }
    }
}
