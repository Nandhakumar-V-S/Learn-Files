﻿using ArcTicketSystem.API.DBContext;
using ArcTicketSystem.API.Model;
using ArcTicketSystem.API.TokenSettings;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

//public class UserController : ControllerBase
//{
//    private readonly TicketContext Token;
//    private readonly Token _token;

//    public UserController(TicketContext DB, IOptions<Token> options)
//    {
//        Token = DB;
//        _token = options.Value;
//    }

//    [HttpPost("Authenticate")]
//    [AllowAnonymous]
//    public IActionResult Authenticate([FromBody] Key Authen)
//    {
//        var user = Token.Users.FirstOrDefault
//            (model => model.Username == Authen.uname && model.Password == Authen.pword);
//        if (user == null)
//        {
//            return Unauthorized();
//        }

//        var tokenhandler = new JwtSecurityTokenHandler();
//        var tokenkey = Encoding.UTF8.GetBytes(_token.Key);
//        var tokenDescriptor = new SecurityTokenDescriptor
//        {
//            Subject = new ClaimsIdentity(
//                new Claim[]
//                {
//                        new Claim(ClaimTypes.Name, Authen.uname),
//                }

//            ),
//            Expires = DateTime.Now.AddSeconds(60),
//            SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(tokenkey), SecurityAlgorithms.HmacSha256)
//        };
//        var token = tokenhandler.CreateToken(tokenDescriptor);
//        string finaltoken = tokenhandler.WriteToken(token);

//        //return Ok(finaltoken);

//        return Ok(new { token = finaltoken });
//    }
//}

namespace ArcTicketSystem.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly TicketContext context;
        public UserController(TicketContext _context)
        {
            context = _context;
        }
        [HttpPost]
        public IActionResult Login([FromBody] Key _key)
        {
            var user = context.Users.FirstOrDefault(o => o.Username == _key.Username && o.Password == _key.Password);
            if (user == null)
            {
                return Unauthorized();
            }

            if (user.Userrole == "Admin")
            {
                var Claims = new List<Claim>
            {
                new Claim  ("Type",user.Userrole.ToString()),
                new Claim  ("username",user.Username.ToString()),
                new Claim  ("userid",user.Userid.ToString())
            };

                var Key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes("Hurrah This is My Seccret Key eheheheheheheh"));

                var Token = new JwtSecurityToken(
                    "https://fbi-demo.com",
                    "https://fbi-demo.com",
                    Claims,
                    expires: DateTime.Now.AddDays(60.0),
                    signingCredentials: new SigningCredentials(Key, SecurityAlgorithms.HmacSha256)
                );
                //return new OkObjectResult(new JwtSecurityTokenHandler().WriteToken(Token));

                var tokenHandler = new JwtSecurityTokenHandler();
                var stringToken = tokenHandler.WriteToken(Token);

                return Ok(new { token = stringToken });
            }
            else
            {
                var Claims = new List<Claim>
            {
                new Claim  ("Type","User"),
                new Claim  ("username",user.Userrole.ToString()),
                new Claim  ("userid",user.Userid.ToString())
            };

                var Key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes("Hurrah This is My Seccret Key eheheheheheheh"));

                var Token = new JwtSecurityToken(
                    "https://fbi-demo.com",
                    "https://fbi-demo.com",
                    Claims,
                    expires: DateTime.Now.AddDays(60.0),
                    signingCredentials: new SigningCredentials(Key, SecurityAlgorithms.HmacSha256)
                );
                //return new OkObjectResult(new JwtSecurityTokenHandler().WriteToken(Token));

                var tokenHandler = new JwtSecurityTokenHandler();
                var stringToken = tokenHandler.WriteToken(Token);

                return Ok(new { token = stringToken });

            }

        }


    }
}
