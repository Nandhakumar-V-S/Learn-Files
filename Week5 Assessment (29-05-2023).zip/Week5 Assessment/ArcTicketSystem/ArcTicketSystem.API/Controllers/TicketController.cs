﻿using ArcTicketSystem.API.Model;
using ArcTicketSystem.API.Repository;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace ArcTicketSystem.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class TicketController : ControllerBase
    {
        private readonly ITicketRepository _ticketRepository;

        public TicketController(ITicketRepository ticketRepository)
        {
            _ticketRepository = ticketRepository;
        }
        [HttpGet]
        public async Task<IEnumerable<Ticket>> GetTickets()
        {
            return await _ticketRepository.Get();
        }
        [HttpGet("{Ticketid:decimal}")]

        public async Task<ActionResult<Ticket>> GetTickets(decimal Ticketid)

        {

            return await _ticketRepository.Get(Ticketid);

        }
        [HttpPost]

        public async Task<ActionResult<Ticket>> PostTickets([FromBody] Ticket ticket)
        {

            var newTicket =await _ticketRepository.Post(ticket);

            return CreatedAtAction(nameof(GetTickets), new { Ticketid = newTicket.Ticketid }, newTicket);

        }
        [HttpPut("{Ticketid}")]

        public async Task<ActionResult> Update(int Ticketid, [FromBody] Ticket ticket)

        {
            if (Ticketid != ticket.Ticketid)

            {

                return BadRequest();

            }

            await _ticketRepository.Update(ticket);

            return Ok(ticket);

        }
        [HttpDelete("{Ticketid}")]

        public async Task<ActionResult> Delete(decimal Ticketid)

        {

            var ticketsDelete = await _ticketRepository.Get(Ticketid);
            if (ticketsDelete == null)

                return NotFound();

            await _ticketRepository.Delete(Ticketid);

            return Ok(ticketsDelete);

        }
    }
}
