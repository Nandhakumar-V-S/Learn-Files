﻿namespace ArcTicketSystem.API.TokenSettings
{
    public class Token
    {
        public string Key { get; set; }
    }
}
