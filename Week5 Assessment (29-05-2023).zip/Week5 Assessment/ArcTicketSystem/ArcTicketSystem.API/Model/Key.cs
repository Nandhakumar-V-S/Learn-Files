﻿namespace ArcTicketSystem.API.Model
{
    public class Key
    {
        public string Username {  get; set; }
        public string Password { get; set; }
    }
}
