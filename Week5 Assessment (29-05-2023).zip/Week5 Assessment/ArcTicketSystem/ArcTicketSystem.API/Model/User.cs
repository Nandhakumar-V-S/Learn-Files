﻿using System.ComponentModel.DataAnnotations;

namespace ArcTicketSystem.API.Model
{
    public class User
    {
        [Key]
        [Required]
        public decimal Userid { get; set; }
        [Required]
        public string Username { get; set; }
        [Required]
        public string Emailid { get; set; }
        [Required]
        public string Password { get; set; }
        public string Userrole { get; set; }
        [Required]
        public string Status { get; set; }
        [Required]
        public DateTime Createdon { get; set; }
    }
}
